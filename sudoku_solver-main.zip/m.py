import time
import os
j = 10000
for i in range(0, j):
    os.system('cls')
    time.sleep(0.0000000001)
    print('''Function's call count: 150
Solved tile count: 15
Board's zero count: 47
     ====Board====
2  3  4  5  1  6  8  7  9
8  7  6  2  4  9  0  0  1
6  5  0  8  3  0  0  0  0
0  0  7  0  0  0  0  8  0
0  6  9  0  0  8  4  2  0
0  0  0  4  0  2  0  0  0
0  0  0  0  0  3  0  4  8
7  0  0  0  0  0  0  0  0
0  0  0  0  0  0  9  0  0''')
    print(i / j)
    time.sleep(0.1)
    
